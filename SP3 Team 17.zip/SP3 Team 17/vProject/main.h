#ifndef MAIN_H
#define MAIN_H

void KeyboardDown(unsigned char key, int x, int y);
void KeyboardUp(unsigned char key, int x, int y);

#endif
